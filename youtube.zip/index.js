'use strict';

var spawn = require('child_process').spawn;
var fs = require('fs');
var ytdl = require('ytdl-core');
var libQ = require('kew');
var path = require('path');
const {google} = require('googleapis');
var dur = require("iso8601-duration");
var querystring = require('querystring');
var https = require('https');
const NodeCache = require('node-cache');
const md5 = require('md5');

var defaultSecrets = require('./auth.json');
var secrets = JSON.parse(JSON.stringify(defaultSecrets));
var token = require('./authToken.json');
var isPollingPermissions = false;

module.exports = Youtube;

const thumbnailQualities = ['maxres', 'standard', 'high', 'medium', 'default'];

function Youtube(context) {
  var self = this;
  self.status = "loaded";

  self.context = context;
  self.commandRouter = self.context.coreCommand;
  self.logger = self.context.logger;
  self.configManager = self.context.configManager;
  self.addQueue = [];
}

Youtube.prototype.onVolumioStart = function () {
  var self = this;
  self.status = "initialized";

  var configFile = self.commandRouter.pluginManager.getConfigurationFile(self.context, 'config.json');
  self.configFile = configFile;

  self.config = new (require('v-conf'))();
  self.config.loadFile(configFile);
  self.itemsPerPage = self.config.get('items_per_page');

  if (!self.config.get('api_default')) {
    secrets.volumio.api_key = self.config.get('api_key');
    secrets.volumio.client_id = self.config.get('client_id');
    secrets.volumio.client_secret = self.config.get('client_secret');
  }

  self.yt = google.youtube({
    version: 'v3',
    auth: secrets.volumio.api_key
  });

  self.getAccessToken();

  if (self.isAccessGranted()) {
    self.accessToken = token;
    self.refreshAuthToken();
    self.updateYtApiAccessToken();
  }

  self.ytCache = new YoutubeCache({
    enabled: self.config.get('cache_enabled'),
    ttl: self.config.get('cache_ttl'),
    maxKeys: self.config.get('cache_max')
  });

  return libQ.resolve();
};

Youtube.prototype.onStart = function () {
  var self = this;
  self.status = "started"

  //Getting the mdp plugin
  self.mpdPlugin = self.commandRouter.pluginManager.getPlugin('music_service', 'mpd');
  self.logger.info("Youtube::onStart Adding to browse sources");
  self.addToBrowseSources();
  return libQ.resolve();
}

Youtube.prototype.onStop = function () {
  var self = this;
  self.status = "stopped";

  self.ytCache.clear();
  self.ytCache.close();

  return libQ.resolve();
};

Youtube.prototype.onRestart = function () {
  var self = this;
  
  return libQ.resolve();
};

Youtube.prototype.onInstall = function () {
  var self = this;
  //Perform your installation tasks here
};

Youtube.prototype.onUninstall = function () {
  var self = this;
  //Perform your deinstallation tasks here
};

Youtube.prototype.getUIConfig = function () {
  var self = this;
  var lang_code = self.commandRouter.sharedVars.get('language_code');
  return self.commandRouter.i18nJson(path.join(__dirname, 'i18n', 'strings_' + lang_code + '.json'),
    __dirname + '/i18n/strings_en.json',
    __dirname + '/UIConfig.json')
    .then(function (uiconf) {

      uiconf.sections[0].content[0].value = self.config.get('api_default');
      uiconf.sections[0].content[1].value = self.config.get('api_key');
      uiconf.sections[0].content[2].value = self.config.get('client_id');
      uiconf.sections[0].content[3].value = self.config.get('client_secret');

      if (self.isAccessGranted()) {
        uiconf.sections[1].description = 'Volumio has access to your YouTube account. We will only use it to display videos related to your account!';
        uiconf.sections[1].content = [];
      } 
      else {
        if (self.accessData && self.accessData.verification_url) {
          uiconf.sections[1].description = uiconf.sections[1].description.replace('{0}', self.accessData.verification_url);
        }
        if (!isPollingPermissions) {
          self.pollPermissions();
        }
        if (!self.accessData) {
          uiconf.sections[1].content[0].value = 'Code not yet available. Please come back later.';
        }
        else if (!self.accessData.user_code) {
          uiconf.sections[1].content[0].value = 'Error obtaining code. Please make sure you have provided the correct Client ID and secret under API Settings (or use Default)!';
        }
        else {
          uiconf.sections[1].content[0].value = self.accessData.user_code;
        }
      }
      uiconf.sections[2].content[0].value = self.config.get('items_per_page');

      uiconf.sections[3].content[0].value = self.config.get('cache_enabled');
      uiconf.sections[3].content[1].value = self.config.get('cache_ttl');
      uiconf.sections[3].content[2].value = self.config.get('cache_max');
      uiconf.sections[3].content[3].value = false;
      
      return uiconf;
    })
    .fail(function () {
      libQ.reject(new Error());
    });
};

Youtube.prototype.setUIConfig = function (data) {
  var self = this;
  //Perform your UI configuration tasks here
};

Youtube.prototype.getConf = function (varName) {
  var self = this;
  //Perform your tasks to fetch config data here
};

Youtube.prototype.setConf = function (varName, varValue) {
  var self = this;
  //Perform your tasks to set config data here
};

Youtube.prototype.getConfigurationFiles = function () {
  return ['config.json'];
}

Youtube.prototype.pause = function () {
  var self = this;
  self.logger.info("Youtube::pause");

  return self.commandRouter.volumioPause();
};


Youtube.prototype.add = function (vuri) {
  var self = this;
  self.logger.info("Youtube::add");

  if (vuri.includes("list=")) {
    var playlistId = decodeURI(vuri.toString()).split("list=")[1].split("&")[0];
    self.addPlaylist(playlistId);
  } else {
    var regex = /https?:\/\/(?:[0-9A-Z-]+\.)?(?:youtu\.be\/|youtube(?:-nocookie)?\.com\S*?[^\w\s-])([\w-]{11})(?=[^\w-]|$)(?![?=&+%\w.-]*(?:['"][^<>]*>|<\/a>))[?=&+%\w.-]*/ig;
    var videoId = vuri.replace(regex, "$1");
    self.commandRouter.pushConsoleMessage(vuri + " kkk " + videoId);
    self.addVideo(videoId);
  }
};

Youtube.prototype.addVideo = function (videoId) {
  var self = this;
  self.logger.info("Youtube::addVideo");

  return self.commandRouter.addQueueItems([{
    uri: videoId,
    service: "youtube"
  }]);
}

Youtube.prototype.addPlaylist = function (playlistId, pageToken) {
  var self = this;
  self.logger.info("Youtube::addPlaylist " + playlistId);

  //Contact Youtube Data API v3 for the list of videos in the playlist
  var request = {
    part: "snippet",
    maxResults: 50,
    playlistId: playlistId
  };

  if (pageToken != undefined)
    request.pageToken = pageToken;

  self.yt.playlistItems.list(request, function (err, result) {
    if (err) {
      //Holy crap, something went wrong :/
      self.logger.error(err.message + "\n" + err.stack);
      deferred.reject(err);
    } else {
      var res = result.data;
      var videos = res.items;
      for (var i = 0; i < videos.length; i++) {
        var video = {
          uri: videos[i].snippet.resourceId.videoId
        }
        self.addQueue = self.addQueue.concat([video]);
      }
      if (res.nextPageToken != undefined) {
        return self.addPlaylist(playlistId, res.nextPageToken);
      } else {
        return self.parseAddQueue();
      }
    }
  });
}

Youtube.prototype.parseAddQueue = function () {
  var self = this;

  var deferred = libQ.defer();
  if (self.addQueue.length > 0) {
    var videoDefer = libQ.defer();
    self.addVideo(self.addQueue[0].uri).then(function () {
      videoDefer.resolve()
    }, function (e) {
      videoDefer.resolve()
    });
    videoDefer.promise.then(function () {
      self.commandRouter.pushConsoleMessage("Added " + self.addQueue[0].url);
      self.addQueue.splice(0, 1);
      if (self.addQueue.length > 0) {
        return self.parseAddQueue();
      } else {
        return deferred.resolve();
      }
    });
  } else {
    return deferred.resolve({
      added: 0
    });
  }
  return deferred.promise;
}

Youtube.prototype.stop = function () {
  var self = this;
  self.logger.info("Youtube::stop");
  return self.commandRouter.volumioStop();
}

Youtube.prototype.handleBrowseUri = function (uri) {
  var self = this;
  self.logger.info('handleBrowseUri: ' + uri);
  self.commandRouter.pushToastMessage('info', 'YouTube', 'Fetching data from YouTube. This may take some time.');

  if (uri.startsWith('youtube')) {
    var uriComponents = self.getUriComponents(uri);
    var baseUri = uriComponents.baseUri;
    var pageToken = uriComponents.pageToken;
    var offset = uriComponents.offset;
    var prevUri = uriComponents.prevUri;
    
    if (baseUri === 'youtube') { //root
      return self.getRootContent(pageToken, offset, prevUri, uri);
    }   
    else if (baseUri === 'youtube/root/subscriptions') {
      return self.getUserSubscriptions(pageToken, offset, prevUri, uri);
    } else if (baseUri === 'youtube/root/playlists') {
      return self.getUserPlaylists(pageToken, offset, prevUri, uri);
    } else if (baseUri === 'youtube/root/likedVideos') {
      return self.getUserLikedVideos(pageToken, offset, prevUri, uri);
    } else if (baseUri === 'youtube/root/activities') {
      return self.getActivities(pageToken, offset, prevUri, uri);
    } else if (baseUri.startsWith('youtube/')) {
      var uriElements = baseUri.split('/');
      var uriLastElement = uriElements.pop();
      if (uriLastElement) {
        if (uriLastElement.startsWith('playlist=')) {
          var playlistId = uriLastElement.substring(9);
          if (playlistId) {
            return self.getPlaylistItems(playlistId, pageToken, offset, prevUri, uri);
          }
        }
        else if (uriLastElement.startsWith('channel=')) {
          var channelId = uriLastElement.substring(8);
          if (channelId) {
            return self.getChannelPlaylists(channelId, pageToken, offset, prevUri, uri);
          }
        }
        else if (uriLastElement.startsWith('search=')) {
          var searchValue = uriLastElement.substring(7);
          if (searchValue) {
            searchValue = decodeURIComponent(searchValue);
            return self.doSearch(searchValue, pageToken, offset, prevUri, uri);
          }
        }
      }
    }
  }

  return libQ.reject();
};

Youtube.prototype.getUriComponents = function(uri) {
  var baseUri = uri;
  var pageToken = '';
  var offset = 0;
  var prevUri = '/';
  if (baseUri.startsWith('youtube/')) {
    // Retrieve pageToken, offset and prevUri (must be in this order and
    // last in the uri)
    var uriElements = baseUri.split('/');
    var uriLastElement = uriElements.pop();
    if (uriLastElement.startsWith('prevUri=')) {
      prevUri = decodeURIComponent(uriLastElement.substring(8));
      baseUri = uriElements.join('/');
      uriLastElement = uriElements.pop();
    }
    if (uriLastElement.startsWith('offset=')) {
      offset = uriLastElement.substring(7);
      baseUri = uriElements.join('/');
      uriLastElement = uriElements.pop();
    }
    if (uriLastElement.startsWith('pageToken=')) {
      pageToken = uriLastElement.substring(10);
      baseUri = uriElements.join('/');
    }
  }
  return {
    baseUri: baseUri,
    pageToken: pageToken,
    offset: offset,
    prevUri: prevUri
  }

}

Youtube.prototype.explodeUri = function (uri) {
  var self = this;
  var deferred = libQ.defer();

  var playlistId = false;
  if (uri.startsWith('youtube/')) {
    var uriComponents = self.getUriComponents(uri);
    var uriLastElement = uriComponents.baseUri.split('/').pop();
    if (uriLastElement && uriLastElement.startsWith('playlist=')) {
      playlistId = uriLastElement.substring(9);
    }
  }

  if (playlistId) {
    self.logger.info("Youtube::explodeUri Playlist: " + uri);
    self.addPlaylist(playlistId);
  } else {
    self.logger.info("Youtube::explodeUri " + "https://youtube.com/oembed?format=json&url=" + uri);

    self.yt.videos.list({
      part: "snippet,contentDetails",
      id: uri
    }, function (err, result) {
      if (err) {
        //Holy crap, something went wrong :/
        self.logger.error(err.message + "\n" + err.stack);
        deferred.reject(err);
      } else if (result.data.items.length == 0) {
        deferred.reject(new Error("Video is not valid"));
      } else {
        var clip = result.data.items[0];
        self.logger.info("Youtube -> " + JSON.stringify(clip));
        
        deferred.resolve({
          uri: uri,
          service: 'youtube',
          name: clip.snippet.title,
          title: clip.snippet.title,
          artist: "Youtube",
          type: 'track',
          albumart: self.getThumbnailUrl(clip, 'high'),
          duration: dur.toSeconds(dur.parse(clip.contentDetails.duration)),
          trackType: "YouTube",
          samplerate: '44 KHz',
          bitdepth: '24 bit'
        });
      }
    });
  }

  return deferred.promise;
};

Youtube.prototype.getYouTubeUrlItemId = function (url, filter) {
  var splitResult = url.split(filter);
  var id = null;
  if (splitResult.length > 1) {
    id = splitResult[1];

    var ampersandPos = id.indexOf("&");
    if (ampersandPos != -1) {
      id = id.substring(0, ampersandPos);
    }
  }

  return id;
};

Youtube.prototype.search = function (query) {
  var self = this;
  if (!query || !query.value || query.value.length === 0) {
    return libQ.resolve([]);
  }

  var searchValue = query.value;

  if (searchValue.indexOf('youtube.com') !== -1) {
    //check if it is a video
    var id = self.getYouTubeUrlItemId(searchValue, 'v=') || self.getYouTubeUrlItemId(searchValue, 'list=');
    if (id) {
      searchValue = id;
    }
  } else if (searchValue.indexOf('youtu.be') !== -1) {
    // support short urls - the ID is after the slash
    searchValue = searchValue.split('/').pop();
  }

  self.commandRouter.pushToastMessage('info', 'YouTube', 'Fetching data from YouTube. This may take some time.');
  return self.doSearch(searchValue, '', 0, 
      '', 'youtube/search=' + encodeURIComponent(searchValue));
};

Youtube.prototype.getState = function () {
  var self = this;
  self.logger.info("Youtube::getState");
};

Youtube.prototype.addToBrowseSources = function () {
  var self = this;
  self.commandRouter.volumioAddToBrowseSources({
    name: 'Youtube',
    uri: 'youtube',
    plugin_type: 'music_service',
    plugin_name: 'youtube',
    albumart: '/albumart?sourceicon=music_service/youtube/youtube.svg'
  });
};

Youtube.prototype.clearAddPlayTrack = function (track) {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::clearAddPlayTrack');

  var deferred = libQ.defer();
  console.log("***** track.uri: " + track.uri);
  ytdl.getInfo("https://youtube.com/watch?v=" + track.uri, {
    quality: "highestaudio"
  }, function (err, info) {
    if (err) {
     console.log(err)
      console.log("Error opening Youtube stream, video is probably not valid.");
    } else {
      self.mpdPlugin.sendMpdCommand('stop', [])
      .then(function () {
        return self.mpdPlugin.sendMpdCommand('clear', []);
      })
      .then(function () {
        return self.mpdPlugin.sendMpdCommand('load "' + info["formats"][0]["url"] + '"', []);
      })
      .fail(function (e) {
        return self.mpdPlugin.sendMpdCommand('add "' + info["formats"][0]["url"] + '"', []);
      })
      .then(function () {
        self.mpdPlugin.clientMpd.on('system', function (status) {
          var timeStart = Date.now();
          self.mpdPlugin.getState().then(function (state) {
            return self.commandRouter.stateMachine.syncState(state, "youtube");
          });
        });
        return self.mpdPlugin.sendMpdCommand('play', []).then(function () {
          return self.mpdPlugin.getState().then(function (state) {
            return self.commandRouter.stateMachine.syncState(state, "youtube");
          });
        });
      });
    }
  });
}

Youtube.prototype.stop = function () {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::stop');
  return self.mpdPlugin.sendMpdCommand('stop',[]).then(function () {
    return self.mpdPlugin.getState().then(function (state) {
      return self.commandRouter.stateMachine.syncState(state, "youtube");
    });
  });
};

Youtube.prototype.pause = function () {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::pause');
  return self.mpdPlugin.sendMpdCommand('pause',[]).then(function () {
    return self.mpdPlugin.getState().then(function (state) {
      return self.commandRouter.stateMachine.syncState(state, "youtube");
    });
  });
};

Youtube.prototype.resume = function () {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::resume');
  return self.mpdPlugin.sendMpdCommand('play',[]).then(function () {
    return self.mpdPlugin.getState().then(function (state) {
      return self.commandRouter.stateMachine.syncState(state, "youtube");
    });
  });
};

Youtube.prototype.seek = function (position) {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::seek(' + position + ')');
  return self.mpdPlugin.seek(position).then(function () {
    return self.mpdPlugin.getState().then(function (state) {
      return self.commandRouter.stateMachine.syncState(state, "youtube");
    });
  });
};

Youtube.prototype.next = function () {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::next');
  return self.mpdPlugin.sendMpdCommand('next', []).then(function () {
    return self.mpdPlugin.getState().then(function (state) {
      return self.commandRouter.stateMachine.syncState(state, "youtube");
    });
  });
};

Youtube.prototype.previous = function () {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::previous');
  return self.mpdPlugin.sendMpdCommand('previous', []).then(function () {
    return self.mpdPlugin.getState().then(function (state) {
      return self.commandRouter.stateMachine.syncState(state, "youtube");
    });
  });
};

Youtube.prototype.prefetch = function (nextTrack) {
  var self = this;
  self.commandRouter.pushConsoleMessage('[' + Date.now() + '] ' + 'Youtube::prefetch');

  ytdl.getInfo("https://youtube.com/watch?v=" + nextTrack.uri, {
    quality: "highestaudio"
  }, function (err, info) {
    if (err) {
    console.log(err);
      console.log("Error opening Youtube stream, video is probably not valid.");
    } else {
      return self.mpdPlugin.sendMpdCommand('add "' + info["formats"][0]["url"] + '"', [])
        .then(function () {
          return self.mpdPlugin.sendMpdCommand('consume 1', []);
        });
    }
  });
};

Youtube.prototype.getRootContent = function (pageToken, offset, prevUri, currentUri) {
  var self = this;

  if (!self.isAccessGranted()) {
    self.commandRouter.pushToastMessage('info', 'Volumio has no permissions', 'Grant Volumio access to your YouTube account to access your playlists.');
    return self.getTrend(pageToken, offset, prevUri, currentUri);
  }

  return libQ.resolve(
    {
      navigation: {
        prev: {
          uri: '/'
        },
        lists:
          [
            {
              title: 'My YouTube',
              icon: 'fa fa-youtube',
              availableListViews: ['list', 'grid'],
              items: [
                {
                  service: 'youtube',
                  type: 'item-no-menu',
                  title: ' Activities',
                  icon: 'fa fa-history',
                  uri: 'youtube/root/activities/prevUri=youtube'
                },
                {
                  service: 'youtube',
                  type: 'item-no-menu',
                  title: 'Subscriptions',
                  icon: 'fa fa-star',
                  uri: 'youtube/root/subscriptions/prevUri=youtube'
                },
                {
                  service: 'youtube',
                  type: 'item-no-menu',
                  title: 'My Playlists',
                  icon: 'fa fa-list',
                  uri: 'youtube/root/playlists/prevUri=youtube'
                },
                {
                  service: 'youtube',
                  type: 'item-no-menu',
                  title: 'Liked Videos',
                  icon: 'fa fa-thumbs-o-up',
                  uri: 'youtube/root/likedVideos/prevUri=youtube'
                }
              ]
            }
          ]
      }
    });
}

Youtube.prototype.getUserSubscriptions = function (pageToken, offset, prevUri, currentUri) {
  var self = this;

  var request = {
    part: "snippet",
    mine: true,
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.subscriptions.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('subscriptions.list', request),
    title: 'My YouTube Subscriptions'
  });
}

Youtube.prototype.getUserLikedVideos = function (pageToken, offset, prevUri, currentUri) {
  var self = this;

  var request = {
    part: "snippet",
    myRating: 'like',
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.videos.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('videos.list', request),
    title: 'Liked Videos',
  });
}

Youtube.prototype.getUserPlaylists = function (pageToken, offset, prevUri, currentUri) {
  var self = this;

  var request = {
    part: "snippet",
    mine: true,
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.playlists.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('playlists.list', request),
    title: 'My YouTube Playlists'
  });
}

Youtube.prototype.getActivities = function (pageToken, offset, prevUri, currentUri) {
  var self = this;

  var request = {
    part: "snippet",
    home: true,
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.activities.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('activities.list', request),
    title: 'YouTube Activities',
  });
}

Youtube.prototype.getTrend = function (pageToken, offset, prevUri, currentUri) {
  var self = this;

  var request = {
    chart: 'mostPopular',
    part: "snippet",
    videoCategoryId: 10,
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.videos.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('videos.list', request),
    title: 'Trending on YouTube'
  });
}

Youtube.prototype.doSearch = function (query, pageToken, offset, prevUri, currentUri) {
  var self = this;

  var request = {
    q: query,
    part: "snippet",
    type: "video,playlist,channel",
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.search.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri === '/' ? 'youtube' : prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('search.list', request),
    title: 'Youtube Search Results',
  });
}

Youtube.prototype.getChannelPlaylists = function (channelId, pageToken, offset, prevUri, currentUri) {
  var self = this;
  console.log('channelId:', channelId);

  var request = {
    channelId: channelId,
    part: "snippet",
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.playlists.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('playlists.list', request),
    title: 'Youtube Channel Playlists'
  });
}

Youtube.prototype.getPlaylistItems = function (playlistId, pageToken, offset, prevUri, currentUri) {
  var self = this;
  console.log('playlistId:', playlistId);

  var request = {
    playlistId: playlistId,
    part: "snippet",
    maxResults: Math.min(self.itemsPerPage, 50),
    pageToken: pageToken
  };

  return self.youtubeRequest({
    apiFunc: function(apiRequest) { return self.yt.playlistItems.list(apiRequest); },
    apiRequest: request,
    offset: offset,
    prevUri: prevUri,
    currentUri: currentUri,
    cacheKey: self.ytCache.getKeyForYoutubeRequest('playlistItems.list', request),
    title: 'Youtube Playlist'
  });
}

Youtube.prototype.youtubeRequest = function (request, cacheList, deferred, inRecursion) {
  var self = this;

  if (!deferred) {
    deferred = libQ.defer();
  }

  if (!cacheList) {
    cacheList = [];
  }

  var offset = request.offset ? request.offset : 0;
  var cacheKey;
  if (request.cacheKey) {
    cacheKey = offset ? request.cacheKey + ':' + offset : request.cacheKey;
  }
  var cachedItems;
  if (cacheKey && !inRecursion) {
    cachedItems = self.ytCache.get(cacheKey);
  }
  if (cachedItems) {
    console.log('Using items from Youtube cache');
    self.resolveYoutubeResponse(cachedItems, request, deferred);
  }
  else {
    request.apiFunc(request.apiRequest).catch(function (err) {
        self.logger.error(err.message + "\n" + err.stack);
        deferred.reject(err);
      }).then(function(result) {
        var res = result.data;
        cacheList = cacheList.concat(res.items);
  
        if (res.nextPageToken && 
            self.itemsPerPage > cacheList.length - offset) {
          request.apiRequest.pageToken = res.nextPageToken;
          self.youtubeRequest(request, cacheList, deferred, true);
        } else {
          var nextPageToken;
          var nextPageOffset;
          // Trim list to fit offset + display limit, while obtaining
          // the correct token and offset for next page if applicable
          if (offset) {
            cacheList = cacheList.slice(offset);
          }
          if (cacheList.length > self.itemsPerPage) {
            nextPageToken = request.apiRequest.pageToken;
            nextPageOffset = res.items.length - (cacheList.length - self.itemsPerPage);
            cacheList = cacheList.slice(0, self.itemsPerPage);
          }
          else if (res.nextPageToken) {
            nextPageToken = res.nextPageToken;
            nextPageOffset = 0;
          }
          // Need to add a 'Next Page' entry to cacheList?
          if (nextPageToken) {
            cacheList.push({
              kind: '#nextPage',
              pageToken: nextPageToken,
              offset: nextPageOffset,
              snippet: {
                title: 'Next Page',
                channelTitle: ''
              }
            });
          }
          // Put list in cache
          if (cacheKey) {
            self.ytCache.put(cacheKey, cacheList);
          }
          self.resolveYoutubeResponse(cacheList, request, deferred);
        }
    });
  }

  return deferred.promise;
}

Youtube.prototype.resolveYoutubeResponse = function(items, request, deferred) {
  var self = this;
  
  if (request.plainResult) {
    deferred.resolve(items);
  } else {
    var listItem = {
      title: request.title,
      icon: 'fa fa-youtube',
      availableListViews: ['list', 'grid'],
      items: self.processResponse(items, request.currentUri)
    };

    if (request.prevUri) {
      deferred.resolve({
        navigation: {
          prev: {
            uri: request.prevUri
          },
          lists: [listItem]
        }
      });
    } else {
      deferred.resolve(listItem)
    }
  }
};

Youtube.prototype.processResponse = function (items, currentUri) {
  var self = this;
  var parsedItems = [];

  for (var i = 0; i < items.length; i++) {
    parsedItems.push(self.parseResponseItemData(items[i], currentUri));
  }

  return parsedItems;
}

Youtube.prototype.parseResponseItemData = function (item, currentUri) {
  var self = this;
  var albumart, url, type, icon;

  albumart = self.getThumbnailUrl(item, 'high');

  if (item.kind) {
    switch (item.kind) {
      case 'youtube#searchResult':
        switch (item.id.kind) {
          case 'youtube#video':
            url = item.id.videoId;
            type = 'song';
            break;
          case 'youtube#playlist':
            url = 'youtube/playlist=' + item.id.playlistId + 
                  '/prevUri=' + encodeURIComponent(currentUri);
            type = 'folder';
            break;
          case 'youtube#channel':
            url = 'youtube/channel=' + item.id.channelId + 
                  '/prevUri=' + encodeURIComponent(currentUri);
            type = 'folder';
            break;
          default:
            url = 'youtube/unhandled-search-kind: ' + item.id.kind;
            break;
        }
        break;
      case 'youtube#video':
        url = item.id;
        type = 'song';
        break;
      case 'youtube#playlist':
        url = 'youtube/playlist=' + item.id + 
              '/prevUri=' + encodeURIComponent(currentUri);
        type = 'folder';
        break;
      case 'youtube#channel':
        url = 'youtube/channel=' + item.id + 
              '/prevUri=' + encodeURIComponent(currentUri);;
        type = 'folder';
        break;
      case 'youtube#playlistItem':
        url = item.snippet.resourceId.videoId;
        type = 'song';
        break;
      case 'youtube#subscription':
        if (item.snippet.resourceId && item.snippet.resourceId.kind === 'youtube#channel') {
          url = 'youtube/channel=' + item.snippet.resourceId.channelId + 
                '/prevUri=' + encodeURIComponent(currentUri);
          type = 'folder';
        } else {
          url = 'youtube/unhandled-subscription-kind: ' + item.kind;
        }
        break;
      case 'youtube#activity':
        url = 'youtube/channel=' + item.snippet.channelId + 
              '/prevUri=' + encodeURIComponent(currentUri);
        type = 'folder';
        break;
      case '#nextPage':
        var uriComponents = self.getUriComponents(currentUri);
        url = uriComponents.baseUri + '/pageToken=' + item.pageToken +
              (item.offset ? '/offset=' + item.offset : '')  + 
              '/prevUri=' + encodeURIComponent(currentUri);
        type = 'item-no-menu';
        icon = 'fa fa-arrow-circle-right';
        break;
      default:
        url = 'youtube/unhandled-kind: ' + item.kind;
        break;
    }
  }

  return {
    service: 'youtube',
    type: type,
    title: item.snippet.title,
    artist: item.snippet.channelTitle,
    albumart: albumart,
    icon: icon,
    uri: url
  };
}

Youtube.prototype.getThumbnailUrl = function(item, targetQuality = 'high') {
  var self = this;

  if (item.snippet && item.snippet.thumbnails) {
    var targetQualityIndex = thumbnailQualities.indexOf(targetQuality);
    if (targetQualityIndex === -1) {
      targetQualityIndex = 2; // high quality
    }
    for (var i = targetQualityIndex; i < thumbnailQualities.length; i++) {
      if (item.snippet.thumbnails[thumbnailQualities[i]]) {
        return item.snippet.thumbnails[thumbnailQualities[i]].url;
      }
    }
  }

  return '';
}

Youtube.prototype.updateGeneralSettings = function (data) {
  var self = this;
  var itemsPerPage = data['items_per_page'];

  if (itemsPerPage <= 0) {
    self.commandRouter.pushToastMessage('error', 'Saving settings failed', 'Items per page must be greater than 0 (zero).');
  } else {
    self.config.set('items_per_page', itemsPerPage);
    if (self.itemsPerPage !== itemsPerPage) {
      self.itemsPerPage = itemsPerPage;
      self.ytCache.clear();
    }
    self.commandRouter.pushToastMessage('info', 'Settings saved', 'Settings successsfully updated.');
  }

  return libQ.resolve();
};

Youtube.prototype.updateAPISettings = function (data) {
  var self = this;
  var defer = libQ.defer();
  var apiDefault = data['api_default'];
  var apiKey = data['api_key'];
  var clientId = data['client_id'];
  var clientSecret = data['client_secret'];

  if (!apiDefault && (!apiKey || !clientId || !clientSecret)) {
    self.commandRouter.pushToastMessage('error', 'Saving settings failed', 'Please provide values for API key, Client ID and Client secret!');
  } else {
    var oldApiDefault = self.config.get('api_default');
    var oldApiKey = self.config.get('api_key');
    var oldClientId = self.config.get('client_id');
    var oldClientSecret = self.config.get('client_secret');
    self.config.set('api_default', apiDefault);
    self.config.set('api_key', apiKey);
    self.config.set('client_id', clientId);
    self.config.set('client_secret', clientSecret);
    self.commandRouter.pushToastMessage('info', 'Settings saved', 'Settings successsfully updated.');

    var resetAuth = (oldApiDefault !== apiDefault) || // Default -> Custom API or vice versa
                (!apiDefault && (oldApiKey !== apiKey || oldClientId !== clientId || oldClientSecret !== clientSecret)); // Custom API + values changed
    
    if (resetAuth) {
      // Clear auth token
      fs.writeFile(path.join(__dirname, 'authToken.json'), JSON.stringify({}), function (err) {
        if (err) {
          self.logger.error('Could not write authToken file:' + err);
        }
      });
      token = {};
      delete self.accessToken;

      // Set new secrets
      if (apiDefault) {
        secrets.volumio.api_key = defaultSecrets.volumio.api_key;
        secrets.volumio.client_id = defaultSecrets.volumio.client_id;
        secrets.volumio.client_secret = defaultSecrets.volumio.client_secret;
      }
      else {
        secrets.volumio.api_key = apiKey;
        secrets.volumio.client_id = clientId;
        secrets.volumio.client_secret = clientSecret;
      }

      // Switch to updated api key
      self.yt = google.youtube({
        version: 'v3',
        auth: secrets.volumio.api_key
      });

      // Refresh accessData (which includes the user code)
      delete self.accessData;
      self.getAccessToken();

      // Clear cache
      self.ytCache.clear();

      // Show modal to user
      var modalData = {
        title: 'Youtube Configuration',
        message: 'API settings have changed. A new code will be provided under Account Access for granting Volumio permission to access your Youtube account.',
        size: 'lg',
        buttons: [
          {
            name: 'Got it!',
            class: 'btn btn-info'
          }
        ]
      }
      self.commandRouter.broadcastMessage("openModal", modalData);

      self.refreshUIConfigOnAPIChanged();
    }
  }

  return defer.promise;
};

Youtube.prototype.updateCacheSettings = function (data) {
  var self = this;
  var cacheEnabled = data['cache_enabled'];
  var cacheTTL = data['cache_ttl'];
  var cacheMax = data['cache_max'];
  
  if (cacheTTL < 60 && cacheTTL !== 0) {
    self.commandRouter.pushToastMessage('error', 'Saving settings failed', 'TTL must be 0 (zero) or not less than 60.');
  } 
  else if (cacheMax <= 0) {
    self.commandRouter.pushToastMessage('error', 'Saving settings failed', 'Max entries must be greater than 0 (zero).');
  }
  else {
    self.config.set('cache_enabled', cacheEnabled);
    self.config.set('cache_ttl', cacheTTL);
    self.config.set('cache_max', cacheMax);
    self.ytCache.setEnabled(cacheEnabled);
    self.ytCache.setTTL(cacheTTL);
    self.ytCache.setMaxKeys(cacheMax);
    self.commandRouter.pushToastMessage('info', 'Settings saved', 'Settings successsfully updated.');
  }

  return libQ.resolve();
};

Youtube.prototype.clearCache = function() {
  var self = this;
  
  self.ytCache.clear();
  self.commandRouter.pushToastMessage('success', 'YouTube', 'Cache cleared!');
}

Youtube.prototype.refreshUIConfigOnAPIChanged = function() {
  var self = this;
  if (self.accessData) {  // Refresh UI when accessData becomes available
    var respconfig = self.commandRouter.getUIConfigOnPlugin('music_service', 'youtube', {});
    respconfig.then(function(config)
    {
        self.commandRouter.broadcastMessage('pushUiConfig', config);
    });
  }
  else {  // accessData unavailable...Try again after 1 second
    setTimeout(self.refreshUIConfigOnAPIChanged.bind(self), 1000);
  }
}

Youtube.prototype.getAccessToken = function () {
  var self = this;
  var deferred = libQ.defer();

  var postData = querystring.stringify({
    'client_id': secrets.volumio.client_id,
    'scope': 'https://www.googleapis.com/auth/youtube.readonly'
  });

  var options = {
    host: 'accounts.google.com',
    path: '/o/oauth2/device/code',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  // Set up the request
  var codeReq = https.request(options, function (res) {
    res.setEncoding('utf8');
    res.on('data', function (chunk) {
      self.accessData = JSON.parse(chunk);
      deferred.resolve(self.accessData);
    });
  });

  codeReq.on('error', (e) => {
    deferred.reject(e);
  });

  codeReq.write(postData);
  codeReq.end();

  return deferred.promise;
}

Youtube.prototype.pollPermissions = function () {
  var self = this;
  var deferred = libQ.defer();

  if (self.status === 'stopped') {
    self.logger.info('Plugin stopped. Not polling anymore.');
    isPollingPermissions = false;
  }
  else if (!self.accessData) {
    self.logger.info('accessData not yet obtained. Retrying in 5 seconds...');
    setTimeout(self.pollPermissions.bind(self), 5000);
    isPollingPermissions = true;
  }
  else if (self.accessData.error) {
    self.logger.error('There was an error fetching accessData. Poll permissions will not proceed!');
    isPollingPermissions = false;
  }
  else {
    var postData = querystring.stringify({
      'client_id': secrets.volumio.client_id,
      'client_secret': secrets.volumio.client_secret,
      'code': self.accessData.device_code,
      'grant_type': 'http://oauth.net/grant_type/device/1.0'
    });

    var options = {
      host: 'www.googleapis.com',
      path: '/oauth2/v4/token',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    // Set up the request
    var codeReq = https.request(options, function (res) {
      res.setEncoding('utf8');

      res.on('data', function (chunk) {
        var data = JSON.parse(chunk);

        if (res.statusCode == '200') {
          fs.writeFile(path.join(__dirname, 'authToken.json'), chunk, function (err) {
            if (err) {
              self.logger.error('Could not save the authentication token!');
            }
          });

          self.accessToken = data;
          token = data;
          self.commandRouter.pushToastMessage('success', 'Access granted', 'Volumio now has access to your YouTube account.');
          self.updateYtApiAccessToken();
          isPollingPermissions = false;

          deferred.resolve(data);
        } else if (res.statusCode == '400' || res.statusCode == '428') { // Code 428 (Precondition Failed) can also be returned for auth pending...
          if (self.accessData && self.accessData.interval) {
            //Authorization pending
            self.logger.info('Authorization pending, polling again in ' + self.accessData.interval + ' seconds.');
            // add one second to polling interval to avoid Polling too frequently error
            setTimeout(self.pollPermissions.bind(self), self.accessData.interval * 1000 + 1000);
          }
          else {
            self.logger.error('accessData reset while waiting for auth response. Will poll again in 5 seconds...');
            setTimeout(self.pollPermissions.bind(self), 5000);
          }
        } else {
          self.commandRouter.pushToastMessage('error', data.error + ' (' + res.statusCode + ')', data.error_description);
          deferred.reject(new Error(data.error + ': ' + data.error_description));
          isPollingPermissions = false;
        }
      });
    });

    codeReq.on('error', (e) => {
      deferred.reject(e);
    });

    codeReq.write(postData);
    codeReq.end();

    isPollingPermissions = true;
  }

  return deferred.promise;
}

Youtube.prototype.refreshAuthToken = function () {
  var self = this;
  var deferred = libQ.defer();

  var postData = querystring.stringify({
    'client_id': secrets.volumio.client_id,
    'client_secret': secrets.volumio.client_secret,
    'refresh_token': self.accessToken.refresh_token,
    'grant_type': 'refresh_token'
  });

  var options = {
    host: 'www.googleapis.com',
    path: '/oauth2/v4/token',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  // Set up the request
  var codeReq = https.request(options, function (res) {
    res.setEncoding('utf8');

    res.on('data', function (chunk) {
      var data = JSON.parse(chunk);

      if (res.statusCode == '200') {
        self.accessToken.expires_in = data.expires_in;
        self.accessToken.access_token = data.access_token;

        fs.writeFile(path.join(__dirname, 'authToken.json'), JSON.stringify(self.accessToken), function (err) {
          if (err) {
            self.logger.error('Could not write authToken file:' + err);
          }
        });

        setTimeout(self.refreshAuthToken.bind(self), self.accessToken.expires_in * 1000);
        self.updateYtApiAccessToken();

        self.logger.info('refresh token again in seconds: ' + self.accessToken.expires_in);

        deferred.resolve({});
      } else {
        self.logger.info('Clearing authentication file!');

        self.commandRouter.pushToastMessage('error', data.error, data.error_description);
        fs.writeFile(path.join(__dirname, 'authToken.json'), JSON.stringify({}), function (err) {
          if (err) {
            self.logger.error('Could not write authToken file:' + err);
          }
        });
        deferred.reject(new Error(data.error + ': ' + data.error_description));
      }
    });
  });

  codeReq.on('error', (e) => {
    deferred.reject(e);
  });

  codeReq.write(postData);
  codeReq.end();

  return deferred.promise;
}

Youtube.prototype.updateYtApiAccessToken = function () {
  var self = this;
  var oauth2Client = new google.auth.OAuth2(
    secrets.volumio.client_id,
    secrets.volumio.client_secret,
    secrets.volumio.redirect_uris[0]
  );

  oauth2Client.setCredentials(self.accessToken);

  self.yt = google.youtube({
    version: 'v3',
    auth: oauth2Client
  });
}

Youtube.prototype.isAccessGranted = function () {
  return token && token.refresh_token && token.access_token;
}

// ====== Cache ======

function YoutubeCache(config) {

  this.enabled = config.enabled;
  this.ttl = config.ttl;
  this.maxKeys = config.maxKeys;

  this._cache = new NodeCache({
    checkperiod: 60
  });

  this.setEnabled = function(enabled) {
    this.enabled = enabled;
    console.log('YoutubeCache: ' + (enabled ? 'enabled' : 'disabled'));
  }

  this.isEnabled = function() {
    return this.enabled;
  }

  this.setTTL = function(ttl) {
    if (this.ttl !== ttl) {
      var keys = this._cache.keys();
      for (var i = 0; i < keys.length; i++) {
        this._cache.ttl(keys[i], ttl);
      }
      this.ttl = ttl;
      console.log('YoutubeCache: all entries updated with ttl: ' + ttl);
    }
  }

  this.setMaxKeys = function(maxKeys) {
    if (this.maxKeys !== maxKeys) {
      var keys = this._cache.keys();
      if (keys.length > maxKeys) {
        console.log('YoutubeCache: removing ' + (keys.length - maxKeys) + ' entries due to lower max value');
        for (var i = 0; i < keys.length - maxKeys; i++) {
          this._cache.del(keys[i]);
        }
      }
      this.maxKeys = maxKeys;
      console.log('YoutubeCache: maxKeys updated to ' + maxKeys);
    }
  }

  this.put = function(key, value) {
    if (this.isEnabled()) {
      var keys = this._cache.keys();
      if (this.maxKeys === keys.length) {
        console.log('YoutubeCache.put(): removing an entry due to maxKeys reached');
        this._cache.del(keys[0]);
      }
      this._cache.set(key, value, this.ttl);
      console.log('YoutubeCache.put(): added entry with key ' + key);
    }
    else {
      console.log('YoutubeCache.put(): cache is disabled');
    }
  }

  this.get = function(key) {
    if (this.isEnabled()) {
      var value = this._cache.get(key);
      if (value) {
        console.log('YoutubeCache.get(): returning value with key ' + key);
        return value;
      }
      else {
        console.log('YoutubeCache.get(): value with key ' + key + ' not found');
        return null;
      }
    }
    else {
      console.log('YoutubeCache.get(): cache is disabled');
      return null;
    }
  }

  this.clear = function() {
    this._cache.flushAll();
    console.log('YoutubeCache: cache cleared!');
  }

  this.close = function() {
    this._cache.close();
    console.log('YoutubeCache closed!');
  }

  // Helper functions

  this.getKeyForYoutubeRequest = function(apiFuncName, apiRequest) {
    return md5(apiFuncName + '(' + JSON.stringify(apiRequest) + ')');
  }

}
